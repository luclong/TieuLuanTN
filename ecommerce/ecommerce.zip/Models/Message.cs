﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ecommerce.Models
{
    public class Message
    {
        public string TextMessage { get; set; }
    }
}