﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ecommerce.Models;

namespace ecommerce.Controllers
{
    public class PaypalController : Controller
    {
        DbecommerceEntities db = new DbecommerceEntities();
        // GET: Paypal
        public List<ItemGioHang> LayGioHang()
        {
            List<ItemGioHang> lstGioHang = Session["GioHang"] as List<ItemGioHang>;
            if (lstGioHang == null)
            {
                lstGioHang = new List<ItemGioHang>();
                Session["GioHang"] = lstGioHang;
            }
            return lstGioHang;
        }
        public ActionResult Index()
        {
            if (Session["GioHang"] == null)
            {
                RedirectToAction("Index", "Home");
            }
            var ls = Session["GioHang"] as List<ItemGioHang>;
            return View(ls);
        }
        public ActionResult GetDataPaypal()
        {
            return View();
        }

    }
}